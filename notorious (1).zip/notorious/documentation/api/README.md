[service-notorious](../../README.md) / API

# API

- [How to use](./how-to-use/README.md)
  - [Authorization](./how-to-use/authorization.md)
  - [Pagination](./how-to-use/pagination.md)
  - [User management](./how-to-use/user-management.md)
- [Projects](./projects/README.md)
  - [Get all projects](./projects/get-all-projects.md)
  - [Get a project](./projects/get-a-project.md)
  - [Delete a project](./projects/delete-a-project.md)
  - [Create a project](./projects/create-a-project.md)
  - [Get all serp's pages](./projects/get-all-serps-pages.md)
  - [Get all backlinks](./projects/get-all-backlinks.md)
  - [Get all features](./projects/get-all-features.md)

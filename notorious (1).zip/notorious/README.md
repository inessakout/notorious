# service-notorious

> API related to the notorious tool of the platform.

API for the netlinking project notorious, Create a project and get all result about netlinking
(score, advised domain). When a project is created,the tool will fetch the matching serp and theirs
metrics and backlinks and analyse with machine learning method to advice backlinks to have.

## Environment variables

| Name        | Type      | Description                                               |
|:------------|:----------|:----------------------------------------------------------|
| `API_KEY`   | `string`  | **Required.** API key needed to authorize to the service. |
| `PORT`      | `number`  |                                                           |
| `LOG_LEVEL` | `string`  | Default to `warn`.                                        |

## API

- [How to use](./documentation/api/how-to-use/README.md)
  - [Authorization](./documentation/api/how-to-use/authorization.md)
  - [Pagination](./documentation/api/how-to-use/pagination.md)
  - [User management](./documentation/api/how-to-use/user-management.md)
- [Projects](./documentation/api/projects/README.md)
  - [Get all projects](./documentation/api/projects/get-all-projects.md)
  - [Get a project](./documentation/api/projects/get-a-project.md)
  - [Delete a project](./documentation/api/projects/delete-a-project.md)
  - [Create a project](./documentation/api/projects/create-a-project.md)
  - [Get all serp's pages](./documentation/api/projects/get-all-serps-pages.md)
  - [Get all backlinks](./documentation/api/projects/get-all-backlinks.md)
  - [Get all features](./documentation/api/projects/get-all-features.md)
